SELECT FIRST_NAME AS "Prenume", LAST_NAME AS "Nume"
FROM employees
